/** Predefined Integer Pascal type */
import java.io.*;

public class IntegerType extends ScalarType implements Serializable {
	public String toString() {
		return "integer";
	}
}
