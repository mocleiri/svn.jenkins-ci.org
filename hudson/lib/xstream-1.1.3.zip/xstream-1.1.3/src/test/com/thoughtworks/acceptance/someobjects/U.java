package com.thoughtworks.acceptance.someobjects;

import com.thoughtworks.acceptance.StandardObject;

public class U extends StandardObject {
    public String aStr;
    public String a_Str;
    public U() {
    }

}
