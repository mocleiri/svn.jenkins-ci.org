package com.thoughtworks.acceptance.someobjects;

/**
 *
 * 
 * @author <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: Protocol.java 99 2004-03-07 10:26:50Z joe $
 */
public class Protocol
{
    private String id;

    public String getId()
    {
        return id;
    }
}
